*PADS-LIBRARY-PART-TYPES-V9*

LR645N5-G TO254P483X1016X2375-3P I ANA 7 1 0 0 0
TIMESTAMP 2025.10.13.00.40.19
"Mouser Part Number" 689-LR645N5-G
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/LR645N5-G?qs=iWbXB9lueyC9mxfxWWKAiQ%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" LR645N5-G
"Description" Microchip LR645N5-G, Single Linear Voltage Regulator, 30mA Adjustable 9  11.5 V, 3-Pin TO-220
"Datasheet Link" http://ww1.microchip.com/downloads/en/DeviceDoc/20005384A.pdf
"Geometry.Height" 4.826mm
GATE 1 3 0
LR645N5-G
1 0 U +VIN
2 0 U GND
3 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
458532/1567563/2.50/3/0/Integrated Circuit
