*PADS-LIBRARY-PART-TYPES-V9*

1.5SMC530CA DIONM7969X262N I DIO 7 1 0 0 0
TIMESTAMP 2025.10.13.02.18.38
"Mouser Part Number" 
"Mouser Price/Stock" 
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" 1.5SMC530CA
"Description" 725V Clamp 2.1A Ipp Tvs Diode Surface Mount DO-214AB (SMCJ)
"Datasheet Link" https://www.littelfuse.com/media?resourcetype=datasheets&itemid=fca4a2fb-129a-4d31-849b-1393b105dcb5&filename=littelfuse-tvs-diode-1-5smc-datasheet
"Geometry.Height" 2.62mm
GATE 1 2 0
1.5SMC530CA
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
17851286/1567563/2.50/2/3/TVS Diode (Bi-directional)
